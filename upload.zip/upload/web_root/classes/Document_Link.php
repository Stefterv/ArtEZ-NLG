<?
class Document_Link extends databaseObject{
	protected static $dbName = "document_links";
	public $rank;
	public $type;
	public $document_id;
	public $item_id;
}
?>