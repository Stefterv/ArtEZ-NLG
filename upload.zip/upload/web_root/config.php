<?php
define("DB_LOC", "localhost");
define("DB_USER", "root");
define("DB_PASS", "root");
define("DB_NAME", "nlg");
?>